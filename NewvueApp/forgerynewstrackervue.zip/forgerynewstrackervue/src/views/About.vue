<template>
  <div class="about">
    <h1>About Us!</h1>
    <p>We are a group of 3 students who are studying computer science at UiS.</p>
    <p>This website is our bachelor thesis</p>

  </div>
</template>

<script>
export default {
    name: 'About',
    
};
</script>


<style>
.about{
  width: 100%;
  color: black;
  text-align: center;
  padding-top: 75px;

}

</style>