<template>
    <footer class="footer mt-auto py-3">
    <div class="container">
        <span class="text-muted">Forgery News Tracker® is Copyright © the University of Stavanger 2021</span>
    </div>
</footer>
</template>

<script>
export default {
    name: "Footer",
    
}
</script>

<style scoped>
.footer{
    padding-top: 50px;
    background-color: #26293C;
    width: 100%;
}
</style>