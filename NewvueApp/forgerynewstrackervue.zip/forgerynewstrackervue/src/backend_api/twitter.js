import Twitter from 'twitter-lite';
// import axios from 'axios';


export default class TwitterLogin{
  Login(){
    const client = new Twitter({
      version: "2",
      consumer_key: "zpt0wHS9rEJOMs5kSnnktHIOh",
      consumer_secret: "14g8CorLV7N5TFVZ0Ot7iFrCq4foAYF9emMCI1o4QNUANdiXDs"
    });
    
    client
      
      .getRequestToken("http://127.0.0.1:8080")
      .then(res =>
        console.log({
          reqTkn: res.oauth_token,
          reqTknSecret: res.oauth_token_secret
        })
      )
      .catch(console.error);
  }
  }
